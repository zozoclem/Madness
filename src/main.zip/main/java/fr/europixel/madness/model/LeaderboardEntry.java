package fr.europixel.madness.model;

public class LeaderboardEntry {

    private final String name;
    private final int value;

    public LeaderboardEntry(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}